public class Floare extends Planta{
    public Floare(String nume, String culoare, int nrPetale, int pret) {
        super(nume, culoare, nrPetale, pret);
    }
@Override
public String toString(){
    StringBuilder message = new StringBuilder();
    message.append("Floricica are numele ");
    message.append(Nume);
    message.append(" ,culoarea ");
    message.append(Culoare);
    message.append(", cu ");
    message.append(getNrPetale());
    message.append(" petale si costa ");
    message.append(getPret());
    message.append(" lei");
    return message.toString();
}
    
}
