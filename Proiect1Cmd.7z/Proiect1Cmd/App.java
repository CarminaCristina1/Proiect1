public class App {
    public static void main(String[] args){
        Planta planta = new Planta("Ardei", "rosu", 0, 7);
        Floare floricica = new Floare("orhidee", "mov", 10, 5);
        Gradina gradina = new Gradina("decor", 2, 3, floricica);
        System.out.println(gradina.toString());
        System.out.println(floricica.toString());
        System.out.println(planta.toString());
    }
}
