public class Gradina {
    public int Lungime;
    public int Latime;
    Planta Planta;
    String Scop;

    public Gradina(Planta planta, int latime, int lungime) {
        Lungime=lungime;
        Latime=latime;
        Scop="nedefinit";
        Planta=planta;
    }

    public Gradina(String scop, int latime, int lungime, Planta planta) {
        Lungime=lungime;
        Latime=latime;
        Scop=scop;
        Planta=planta;
    }

    public Planta getPlanta() {
        return Planta;
    }

    public void setPlanta(Planta planta){
        Planta=planta;
    }

    public String getScop() {
        return Scop;
    }

    public void setScop(String scop){
        Scop=scop;
    }

    public String toString(){
        StringBuilder message = new StringBuilder();
        message.append("Gradina are lungimea de ");
        message.append(Lungime);
        message.append(" ,latimea de ");
        message.append(Latime);
        message.append(", construita in scopul ");
        message.append(Scop);
        message.append(". Informatii planta: ");
        message.append(Planta.toString());
        return message.toString();
    }


}
