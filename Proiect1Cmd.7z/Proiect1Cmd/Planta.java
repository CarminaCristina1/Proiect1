public class Planta{
    public Planta(String nume, String culoare, int nrPetale, int pret) {
        Nume = nume;
        Culoare = culoare;
        NrPetale = nrPetale;
        Pret = pret;
    }

    public Planta(String nume, String culoare) {
        Nume = nume;
        Culoare = culoare;
    }

    public String Nume;
    public String Culoare;
    private int NrPetale;
    private int Pret;

    public int getPret() {
        return Pret;
    }

    public void setPret(int pret){
        Pret=pret;
    }

    public int getNrPetale() {
        return NrPetale;
    }

    public void setNrPetale(int nrPetale){
        NrPetale=nrPetale;
    }

    public String toString(){
        StringBuilder message = new StringBuilder();
        message.append("Planta are numele ");
        message.append(Nume);
        message.append(" ,culoarea ");
        message.append(Culoare);
        message.append(", cu ");
        message.append(NrPetale);
        message.append(" petale si costa ");
        message.append(Pret);
        message.append(" lei");
        return message.toString();
    }
}